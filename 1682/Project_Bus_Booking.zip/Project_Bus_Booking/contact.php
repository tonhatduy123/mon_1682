<style>
.contact {
    text-align: center;
}
</style>
<h1 class="contact"><b>CONTACT US</b></h1>
<div class="contact">
    <iframe
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3928.861208898864!2d105.77602181461582!3d10.02830999283179!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31a088216a9ce555%3A0xc42730e6d0681b82!2zMTYwIMSQxrDhu51uZyAzMCBUaMOhbmcgNCwgWHXDom4gS2jDoW5oLCBOaW5oIEtp4buBdSwgQ-G6p24gVGjGoSwgVmlldG5hbQ!5e0!3m2!1sen!2s!4v1620184881273!5m2!1sen!2s"
        width="1000" height="500" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
</div>
<div class="container">
    <div class="col-sm-3">
    </div>
    <div class="col-sm-9">
        <p><span class="glyphicon glyphicon-map-marker"></span><a
                href="https://www.google.com/maps/place/160+%C4%90%C6%B0%E1%BB%9Dng+30+Th%C3%A1ng+4,+Xu%C3%A2n+Kh%C3%A1nh,+Ninh+Ki%E1%BB%81u,+C%E1%BA%A7n+Th%C6%A1,+Vietnam/@10.0283179,105.7782818,19.22z/data=!4m5!3m4!1s0x31a088216a9ce555:0xc42730e6d0681b82!8m2!3d10.02831!4d105.7782105?hl=en"
                target="_blank">
                &nbsp; 160 30/4 Stress, Xuan Khanh Ward, Ninh Kieu District, Can Tho City</p></a>
        <p><span class="glyphicon glyphicon-phone"></span><a href="tel:0386363677"> &nbsp; Phone: 0915425014
        </p></a>
        <p><span class="glyphicon glyphicon-envelope"></span><a href="mailto:luanlcgcc19023@fpt.edu.vn"> &nbsp;
                Buslinebooking@gamil.com</p></a>
        <p><i class="fa fa-facebook-square"></i><a href="https://www.facebook.com/chiluanIT/" target="_blank"></i>
                &nbsp; Facebook</a></p>
        <p><i class="fa fa-youtube-play"></i><a href="https://www.youtube.com/channel/UCrPtllO8vMav1uVaepmqp7A"
                target="_blank"></i> &nbsp;Youtube</a></p>
    </div>
</div>
</div>