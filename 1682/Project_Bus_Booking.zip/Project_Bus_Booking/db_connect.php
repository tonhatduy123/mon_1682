<?php
$conn= new mysqli('localhost','root','','project_bus_booking')or die("Could not connect to mysql".mysqli_error($con));

?>